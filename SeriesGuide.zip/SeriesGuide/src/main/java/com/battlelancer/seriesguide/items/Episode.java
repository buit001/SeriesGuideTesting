
package com.battlelancer.seriesguide.items;

public class Episode {
    public int episodeId;

    public int episodeNumber;

    public int seasonNumber;

}
