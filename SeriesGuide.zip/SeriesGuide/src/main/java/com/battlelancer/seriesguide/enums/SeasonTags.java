package com.battlelancer.seriesguide.enums;

public interface SeasonTags {

    String NONE = "";

    String SKIPPED = "skipped";

}
