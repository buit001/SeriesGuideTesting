package com.battlelancer.seriesguide.billing.amazon;

import com.battlelancer.seriesguide.ui.BaseActivity;

/**
 * No-op dummy. Only available in amazon build.
 */
public class AmazonBillingActivity extends BaseActivity {
}
